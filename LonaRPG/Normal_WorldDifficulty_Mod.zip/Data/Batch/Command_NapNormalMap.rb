$game_actors[1].urinary_level  += rand(1000) if $game_actors[1].urinary_level <=1000
$game_actors[1].lactation_level += 100*((2*$game_actors[1].state_stack(36)) + $game_player.actor.stat["Mod_MilkGland"]*10) #STATE增加乳汁
$game_actors[1].lactation_level =0 if $game_actors[1].state_stack(36) ==0 && $game_player.actor.stat["Mod_MilkGland"] ==0 #STATE -乳汁
$game_actors[1].defecate_level += rand(300) if $game_actors[1].defecate_level  <=1000
#$game_actors[1].dirt +=100 if $game_actors[1].state_stack(39) ==1
$game_actors[1].arousal = rand(50) #reset basic arousal each nap
$game_actors[1].sta += 20+rand(20)+$game_actors[1].sat    #heal up sta/nap
$game_actors[1].health+= (-20+(0.6*($game_actors[1].sat+($game_player.actor.stat["WeakSoul"]*15)))).round #heal up hp /nap
$game_actors[1].baby_health += (15+$game_actors[1].sat )+(0.6*($game_actors[1].sat+($game_player.actor.stat["WeakSoul"]*10))).round if $game_actors[1].preg_level !=0

#當穴還未壞掉時治療穴傷害
$game_actors[1].vag_damage -=rand(150)		if $game_actors[1].state_stack(41) ==0 
$game_actors[1].urinary_damage -=rand(150)	if $game_actors[1].state_stack(42) ==0
$game_actors[1].anal_damage -=rand(150)		if $game_actors[1].state_stack(43) ==0
#基於寄生蟲追加傷害
$game_actors[1].urinary_damage += 150*$game_player.actor.state_stack(94) #壺蟲
$game_actors[1].anal_damage += 150*$game_player.actor.state_stack(93) #月蟲
$game_player.actor.add_state(93) if $game_player.actor.state_stack(93) !=0 && rand(100) >= 80 - 5*$game_player.actor.state_stack(93) #寄生蟲增長 月蟲
$game_player.actor.add_state(94) if $game_player.actor.state_stack(94) !=0 && rand(100) >= 80 - 5*$game_player.actor.state_stack(94) #寄生蟲增長 壺蟲
$game_player.actor.add_state(93) if $game_player.actor.state_stack(96) ==1 #苗床化寄生蟲增長 月蟲
$game_player.actor.add_state(94) if $game_player.actor.state_stack(97) ==1 #苗床化寄生蟲增長 壺蟲
$game_player.actor.add_state(96) if $game_player.actor.state_stack(93) ==5 && rand(100) >=60 #月蟲苗床化
$game_player.actor.add_state(97) if $game_player.actor.state_stack(94) ==5 && rand(100) >=60 #壺蟲苗床化

#藥物成癮控制
$game_actors[1].drug_addiction_level =100 if $game_actors[1].drug_addiction_level <100 && $game_actors[1].state_stack(103) !=0
$game_actors[1].drug_addiction_damage -=rand(300)

#精液中毒控制
$game_actors[1].semen_addiction_level =100 if $game_actors[1].semen_addiction_level <100 && $game_actors[1].state_stack(102) !=0
$game_actors[1].semen_addiction_damage -=rand(300)

#精液中毒控制
$game_actors[1].ograsm_addiction_level =100 if $game_actors[1].ograsm_addiction_level <100 && $game_player.actor.stat["OgrasmAddiction"] !=0
$game_actors[1].ograsm_addiction_damage -=rand(300)

$game_actors[1].sat -=18 #basic -sat /nap
$game_actors[1].sat -=12 if $story_stats["Setup_Hardcore"] >= 1 #basic -sat /nap
$game_actors[1].sat -= $game_actors[1].state_stack(93)+$game_actors[1].state_stack(94)+ $game_player.actor.state_stack(96)+$game_player.actor.state_stack(97)#寄生蟲消耗食物

$game_actors[1].puke_value_normal =0 if $game_actors[1].state_stack(27) ==0 #StomachSpasm
$game_actors[1].puke_value_normal =300 if $game_actors[1].state_stack(27) ==1 #StomachSpasm
$game_actors[1].puke_value_preg +=35+rand(10) if $game_actors[1].preg_level.between?(1,5)
$game_actors[1].pain_value_preg +=30+rand(10) if $game_actors[1].preg_level.between?(2,5)

$game_actors[1].sat -=3+(2*$game_actors[1].preg_level) if $game_actors[1].preg_level >=1 #basic -sat /nap/preg
$game_actors[1].remove_state_stack(32) if $game_actors[1].state_stack(32) >=1 # remove outside lust pill effect
$game_actors[1].remove_state_stack(32) if $game_actors[1].state_stack(32) >=1 # remove outside lust pill effectw
$game_actors[1].erase_state(31)#clear feels warm
$game_actors[1].erase_state(33)#clear just cummed
$game_actors[1].erase_state(34)#clear over cummed
$game_actors[1].erase_state(30)#remove feels sick
$game_actors[1].erase_state(27)#remove StomachSpasm
$game_actors[1].erase_state(25)#Contraceptived避孕藥
$game_actors[1].erase_state(44)#Masturbationed
$game_actors[1].erase_state(46)#DRUNK
$game_actors[1].erase_state(46)#DRUNK
$game_actors[1].erase_state(46)#DRUNK
$game_actors[1].remove_combat_state


if $game_actors[1].state_stack(28) >=1 then $game_actors[1].erase_state(28); $game_actors[1].dirt +=26 end  #clear wet and add dirt
if $game_actors[1].state_stack(37) >=1 then $game_actors[1].erase_state(37); $game_actors[1].dirt +=26 end  #clear Vagbleed and add dirt
if $game_actors[1].state_stack(40) >=1 then $game_actors[1].erase_state(40); $game_actors[1].dirt +=26 end  #clear Analbleed and add dirt
if $game_actors[1].state_stack(39) >=1 then $game_actors[1].erase_state(39); $game_actors[1].dirt +=50 end  #clear Analbleed and add dirt
$game_player.actor.dirt +=26 #basic dirt every nap
$game_player.actor.gain_exp(rand(300) + $game_player.actor.level) #exp each nap
$game_player.actor.heal_wound #heal  up cums and wounds each nap
$game_player.actor.healCums("CumsMoonPie", 100)
$game_player.actor.healCums("CumsCreamPie", 100)
$game_player.actor.healCums("CumsHead", 100)
$game_player.actor.healCums("CumsTop", 100)
$game_player.actor.healCums("CumsMid", 100)
$game_player.actor.healCums("CumsBot", 100)
$game_player.actor.healCums("CumsMouth", $game_player.actor.cumsMeters["CumsMouth"])

$game_actors[1].mood -=10 if $game_actors[1].sat ==0  #how sat effect mood
$game_actors[1].mood -=10 if $game_actors[1].sat <=10
$game_actors[1].mood -=10 if $game_actors[1].sat <=20
$game_actors[1].mood +=10 if $game_actors[1].sat >=20
$game_actors[1].mood +=10 if $game_actors[1].sat >=40
$game_actors[1].mood +=10 if $game_actors[1].sat >=80

$game_party.lose_gold($game_party.gold) if $story_stats["Captured"] ==1
$game_actors[1].wet_dialog =1
$game_actors[1].sta_dialog =1
$game_actors[1].sat_dialog =1
$game_actors[1].heavy_cums_dialog =1
$game_actors[1].cuff_dialog =1
$game_actors[1].collar_dialog =1
$game_actors[1].dress_out_dialog =1
$game_actors[1].defecate_dialog =1 if !$game_map.isOverMap
$game_actors[1].urinary_dialog =1 if !$game_map.isOverMap
$game_actors[1].defecated_dialog =1 if !$game_map.isOverMap
$game_actors[1].overweight_dialog =1
$game_actors[1].lactation_dialog =1
$game_actors[1].sick_dialog =1
$game_actors[1].drug_addiction_dialog =1
$game_player.actor.moon_worm_hit_dialog =1
$game_player.actor.pot_worm_hit_dialog =1
$game_player.actor.parasited_dialog =1
$game_actors[1].milking_babies_dialog =0 if !$game_map.interpreter.player_carry_babies?
$game_actors[1].milking_babies_dialog =1 if $game_map.interpreter.player_carry_babies?
$story_stats["WorldDifficulty"] = ([$story_stats["WorldDifficulty"]+(rand(7)-2),100].min).abs
$game_boxes.box(65536).clear

$game_player.actor.belly_size_control
$game_player.actor.set_action_state(:none,true)