
SndLib.bgm_play("Cave/Espionage LOOP MOVING",80)
SndLib.bgs_play("Cave/Cavern Sound effect_Short",50)


$game_map.shadows.set_color(0, 20, 40)
$game_map.shadows.set_opacity(130)
$game_map.interpreter.map_background_color(80,80,200,40,0)

p "########## BIOS AUTORUN SETUP ##########"
$game_player.direction = 2 if $story_stats["ReRollHalfEvents"] ==1
fadeout2=$story_stats["ReRollHalfEvents"] ==1
newgame=$story_stats["RecordFirstMissionBegin"] ==0 
fadeout = newgame || fadeout2
enter_static_tag_map(nil,fadeout) if $story_stats["ReRollHalfEvents"] == 1
summon_companion


if $story_stats["RecordFirstMissionBegin"] ==0 
 $story_stats["RecordFirstMissionBegin"] =1
 $story_stats["WorldDifficulty"] = 15
 $game_player.direction = 6
 call_msg("MainTownSewer:Sewer/MissionStart0")
 portrait_hide
 call_msg("MainTownSewer:Sewer/MissionStart1")
 call_msg("MainTownSewer:Sewer/MissionStart2")
end
SndLib.bgm_play("Cave/Espionage LOOP MOVING",80)

eventPlayEnd

get_character(0).erase