module GIM_OVC
	
	def checkOev_SlotDMG(parallel=false)
		if $game_player.actor.stat["VaginalDamaged"] == 1 && $game_player.actor.vag_damage >= 9999
			$game_player.actor.add_state("VaginalDamaged") #41
			overEVcall_msg("common:Lona/vag_damaged",parallel)
			eventPlayEnd
		end
		
		if $game_player.actor.stat["UrethralDamaged"] == 1 && $game_player.actor.urinary_damage >= 9999
			$game_player.actor.add_state("UrethralDamaged") #42
			overEVcall_msg("common:Lona/urinary_damaged",parallel)
			eventPlayEnd
		end
		
		if $game_player.actor.stat["SphincterDamaged"] == 1 && $game_player.actor.anal_damage >= 9999
			$game_player.actor.add_state("SphincterDamaged") #43
			overEVcall_msg("common:Lona/anal_damaged",parallel)
			eventPlayEnd
		end
	end
end # class

